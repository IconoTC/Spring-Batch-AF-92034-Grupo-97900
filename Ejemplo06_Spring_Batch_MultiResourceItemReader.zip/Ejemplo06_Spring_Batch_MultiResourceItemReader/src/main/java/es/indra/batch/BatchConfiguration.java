package es.indra.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.builder.MultiResourceItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import es.indra.models.Producto;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
	/*
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	*/
	
	
	// Crear un job
	@Bean
	public Job crearJob(JobBuilderFactory jobBuilderFactory, Step step1) {
		return jobBuilderFactory.get("productosJob")
				.start(step1)
				.build();
	}
	
	// Crear un step
	@Bean
	public Step step1(StepBuilderFactory stepBuilderFactory,
					  ItemReader<Producto> multiResourceItemReader,
					  ItemWriter<Producto> itemWriter) {
		return stepBuilderFactory.get("step1")
				.<Producto,Producto>chunk(4)  // nº de registros que leemos en cada bloque
				.reader(multiResourceItemReader)
				.writer(itemWriter)
				.build();
	}
	
	// Crear el MultiResourceItemReader
	@Bean
	@StepScope
	public MultiResourceItemReader<Producto> multiResourceItemReader(
			@Value("file:src/main/resources/input/data*.csv") Resource[] resources ){
		return new MultiResourceItemReaderBuilder<Producto>()
				.name("multiResourceItemReader")
				.resources(resources)
				.delegate(reader())  // cada datax.csv se lo pasa al reader()
				.build();
	}
	
	// Crear un ItemReader
	@Bean
	@StepScope
	public FlatFileItemReader<Producto> reader(){
		return new FlatFileItemReaderBuilder<Producto>()
				.name("productoItemReader")
				.delimited()
				.names("id", "descripcion", "precio")
				.fieldSetMapper(new BeanWrapperFieldSetMapper<Producto>() {
					{
						setTargetType(Producto.class);
					}
				}).build();
	}
	
	// Crear el writer
	@Bean
	@StepScope
	public FlatFileItemWriter<Producto> writer(
			@Value("file:src/main/resources/output/resultado.csv") Resource resource  ){
		return new FlatFileItemWriterBuilder<Producto>()
				.name("writer")
				.resource(resource)
				.delimited()
				.delimiter(",")
				.names("id", "descripcion", "precio")
				.build();
	}
	

}








