package es.indra.batch;

import java.util.Iterator;
import java.util.List;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.stereotype.Component;

import es.indra.models.Producto;

//@Component
public class CustomReader implements ItemReader<Producto>{
	
	private Iterator<Producto> iterator;
	
	public CustomReader(List<Producto> productos) {
		iterator = productos.iterator();
	}
	
	@Override
	public Producto read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
	
		System.out.println("Leyendo productos ........");
		
		if (iterator.hasNext()) {
			return iterator.next();
		}
		
		// Cuando ya no hay mas productos, retorno null para finalizar el CustomReader
		return null;
	}

}
