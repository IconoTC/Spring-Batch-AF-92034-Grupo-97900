package es.indra.batch;

import java.util.Arrays;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

import es.indra.models.Producto;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	// Crear un job
	@Bean
	public Job crearJob() {
		return jobBuilderFactory.get("productosJob")
				.flow(step1())
				.end()
				.build();
	}
	
	// Crear un step
	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1")
				.<Producto,Producto>chunk(1)  // nº de registros que leemos en cada bloque
				.reader(reader())
				.writer(writer())
				.taskExecutor(taskExecutor())
				.throttleLimit(5)  // limitar el numero de hilos a 5
				.build();
	}
	
	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor asyncTaskExecutor = new SimpleAsyncTaskExecutor("spring_batch");
		asyncTaskExecutor.setConcurrencyLimit(3); // Limita a 3 hilos simultaneos
		return asyncTaskExecutor;
	}
	
	// Crear un ItemReader
	@Bean
	public CustomReader reader(){
		List<Producto> lista = Arrays.asList(
				new Producto(1,"Portatil",1400),
				new Producto(2,"Raton",45),
				new Producto(3,"Pantalla",156),
				new Producto(4,"Disco externo",120),
				new Producto(5,"Altavoces",95));
		return new CustomReader(lista);
	}
	
	// Crear un ItemWriter
	@Bean
	public CustomWriter writer(){
		return new CustomWriter();
	}

}








