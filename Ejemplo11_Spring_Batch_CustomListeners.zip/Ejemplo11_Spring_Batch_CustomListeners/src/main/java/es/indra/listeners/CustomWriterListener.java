package es.indra.listeners;

import java.util.List;

import org.springframework.batch.core.ItemWriteListener;

import es.indra.models.Producto;

public class CustomWriterListener implements ItemWriteListener<Producto>{

	@Override
	public void beforeWrite(List<? extends Producto> items) {
		System.out.println("Empezamos a escribir " + items);
	}

	@Override
	public void afterWrite(List<? extends Producto> items) {
		System.out.println("Terminamos de escribir " + items);
	}

	@Override
	public void onWriteError(Exception ex, List<? extends Producto> items) {
		System.out.println("Ha ocurrido un error al escribir " + items);
		ex.printStackTrace();
		
	}

}
