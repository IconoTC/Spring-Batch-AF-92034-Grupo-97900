package es.indra.listeners;

import org.springframework.batch.core.ItemReadListener;

import es.indra.models.Producto;

public class CustomReaderListener implements ItemReadListener<Producto>{

	@Override
	public void beforeRead() {
		System.out.println("beforeRead() de CustomReaderListener");
	}

	@Override
	public void afterRead(Producto item) {
		System.out.println("afterRead() de CustomReaderListener " + item);
		
	}

	@Override
	public void onReadError(Exception ex) {
		System.out.println("onReadError() de CustomReaderListener " + ex);	
	}

}
