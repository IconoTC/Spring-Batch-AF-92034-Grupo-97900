package es.indra.listeners;

import org.springframework.batch.core.ItemProcessListener;

import es.indra.models.Producto;

public class CustomProcesorListener implements ItemProcessListener<Producto, Producto>{

	@Override
	public void beforeProcess(Producto item) {
		System.out.println("beforeProcess() de CustomProcesorListener");
	}

	@Override
	public void afterProcess(Producto item, Producto result) {
		System.out.println("afterProcess() de CustomProcesorListener");
	}

	@Override
	public void onProcessError(Producto item, Exception e) {
		System.out.println("onProcessError() de CustomProcesorListener " + item + e);
	}

}
