package es.indra.batch;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.EnableRetry;

import es.indra.listeners.CustomProcesorListener;
import es.indra.listeners.CustomReaderListener;
import es.indra.listeners.CustomWriterListener;
import es.indra.models.Producto;

@Configuration
@EnableBatchProcessing
@EnableRetry
public class BatchConfiguration {
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private DataSource dataSource;
	
	@Bean
	public Job crearJob() {
		return jobBuilderFactory.get("productosJob")
				.flow(step1())
				.end()
				.build();
	}
	
	/*
	 * Manejamos el ERROR intentando volver a ejecutarlo
	 * */
	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1")
				.<Producto,Producto>chunk(1)  // nº de registros que leemos en cada bloque
				.reader(reader())
				.processor(processor())
				.writer(writer())
				.faultTolerant() // En caso de fallo
				.retryLimit(2)  // intenta ejecutarlo 2 veces
				.retry(RuntimeException.class) // si la excepcion es de tipo RuntimeExcepcion
				.allowStartIfComplete(true) // Permite el reinicio		
				.listener(customReaderListener())
				.listener(customProcesorListener())
				.listener(customWriterListener())
				.build();
	}
	
	
	/*
	 * Manejamos el ERROR capturandolo y la ejecucion del job continua
	 * 
	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1")
				.<Producto,Producto>chunk(1)  // nº de registros que leemos en cada bloque
				.reader(reader())
				.processor(processor())
				.writer(writer())
				.faultTolerant() // En caso de fallo
				.skipLimit(2) // maximo 2 elementos omitidos
				.skip(RuntimeException.class) // omite este tipo de excepciones
				.noSkip(NullPointerException.class)  // Esta, no se puede omitir
				.allowStartIfComplete(true) // Permite el reinicio
				.listener(customReaderListener())
				.listener(customProcesorListener())
				.listener(customWriterListener())
				.build();
	}
	*/

	@Bean
	public CustomReader reader(){
		return new CustomReader();
	}
	
	@Bean
	public CustomProcesor processor() {
		return new CustomProcesor();
	}
	
	// Crear un ItemWriter
	@Bean
	public CustomWriter writer(){
		return new CustomWriter();
	}
	
	@Bean
	public CustomReaderListener customReaderListener() {
		return new CustomReaderListener();
	}
	
	@Bean
	public CustomProcesorListener customProcesorListener() {
		return new CustomProcesorListener();
	}
	
	@Bean
	public CustomWriterListener customWriterListener() {
		return new CustomWriterListener();
	}

}








