package es.indra.batch;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

import es.indra.models.Producto;

public class CustomReader implements ItemReader<Producto>{
	
	static int contador = 0;

	@Override
	public Producto read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		contador++;
		
		if(contador > 10) {
			// El step termina cuando el reader retorna null
			return null;
		}
			
		Producto producto = new Producto(contador, "Producto " + contador , contador * 100);
		return producto;
	}

}
