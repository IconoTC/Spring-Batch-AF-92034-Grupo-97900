package es.indra.batch;

import org.springframework.batch.item.ItemProcessor;

import es.indra.models.Producto;

public class CustomProcesor implements ItemProcessor<Producto, Producto>{

	@Override
	public Producto process(Producto producto) throws Exception {
		// Aplicamos un 10% de dto en el precio del producto
		// La descripcion la cambiamos a mayusculas

		if (producto.getId() == 3) {
			throw new RuntimeException("Error en el CustomProcesor");
		}
		
		producto.setPrecio(producto.getPrecio() * 0.9);
		producto.setDescripcion(producto.getDescripcion().toUpperCase());
		
		return producto;
	}

}
