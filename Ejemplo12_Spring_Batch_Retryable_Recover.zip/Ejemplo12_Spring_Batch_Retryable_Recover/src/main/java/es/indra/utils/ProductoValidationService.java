package es.indra.utils;

import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import es.indra.models.Producto;

@Service
public class ProductoValidationService {

    private final AtomicInteger counter = new AtomicInteger();

    @Retryable(
            value = ExternalServiceException.class,
            maxAttempts = 3,
            backoff = @Backoff(delay = 2000)
    )
    public String validate(Producto producto) {

        int attempt = counter.incrementAndGet();

        System.out.println(
                "Intento " + attempt +
                " para cliente " + producto.getDescripcion());

        throw new ExternalServiceException(
                "Servicio externo no disponible");
    }

    /*
     * El metodo debe cumplir estas reglas:
     * 		- Primer parámetro: excepción.
			- Resto de parámetros: los mismos del método anotado con @Retryable.
			- Tipo de retorno igual al método original.
     * */
    @Recover
    public String recover(ExternalServiceException ex, Producto producto) {
        System.out.println(
                "RECOVER ejecutado para "
                + producto.getDescripcion());

        return "VALIDACION_FALLIDA";
    }
}

