package es.indra.batch;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import es.indra.models.Producto;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private DataSource dataSource;
	
	// Crear un job
	@Bean
	public Job crearJob() {
		return jobBuilderFactory.get("productosJob")
				.flow(step1())
				.end()
				.build();
	}
	
	// Crear un step
	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1")
				.<Producto,Producto>chunk(1)  // nº de registros que leemos en cada bloque
				.reader(reader())
				.processor(processor())
				.writer(writer())
				.build();
	}
	
	// Crear un ItemReader
	@Bean
	public CustomReader reader(){
		return new CustomReader();
	}
	
	// Crear un ItemProcessor
	@Bean
	public CustomProcesor processor() {
		return new CustomProcesor();
	}
	
	// Crear un ItemWriter
	@Bean
	public CustomWriter writer(){
		return new CustomWriter();
	}

}








