package es.indra.batch;

import java.util.Scanner;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

import es.indra.models.Producto;

public class CustomReader implements ItemReader<Producto>{
	
	static int contador = 0;

	@Override
	public Producto read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		contador++;
		
		if(contador > 1) {
			// El step termina cuando el reader retorna null
			return null;
		}
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce ID: ");
		int id = sc.nextInt();
		
		System.out.println("Introduce Descripcion: ");
		String descripcion = sc.next();
		
		System.out.println("Introduce Precio: ");
		String precioTxt = sc.next();
		double precio = Double.parseDouble(precioTxt);
		sc.close();	
		
		Producto producto = new Producto(id, descripcion, precio);
		return producto;
	}

}
