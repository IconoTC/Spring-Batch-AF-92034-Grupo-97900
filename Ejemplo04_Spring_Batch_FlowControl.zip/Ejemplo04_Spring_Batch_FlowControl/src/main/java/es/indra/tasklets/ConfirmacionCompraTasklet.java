package es.indra.tasklets;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

public class ConfirmacionCompraTasklet implements Tasklet{

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		System.out.println("Ejecutando ConfirmacionCompraTasklet");
		
		contribution.setExitStatus(ExitStatus.FAILED);
		//contribution.setExitStatus(ExitStatus.COMPLETED);
		
		return RepeatStatus.FINISHED;
	}

}
