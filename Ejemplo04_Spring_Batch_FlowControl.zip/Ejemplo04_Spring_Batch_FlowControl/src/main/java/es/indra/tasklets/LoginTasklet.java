package es.indra.tasklets;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

public class LoginTasklet implements Tasklet{

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		System.out.println("Ejecutando LoginTasklet");
		
		if (false)
			contribution.setExitStatus(ExitStatus.FAILED);
		else
			contribution.setExitStatus(ExitStatus.COMPLETED);
		
		return RepeatStatus.FINISHED;
	}

}
