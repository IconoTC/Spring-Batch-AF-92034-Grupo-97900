package es.indra.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import es.indra.tasklets.ConfirmacionCompraTasklet;
import es.indra.tasklets.ErrorTasklet;
import es.indra.tasklets.LoginTasklet;
import es.indra.tasklets.PagoTasklet;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public LoginTasklet loginTasklet() {
		return new LoginTasklet();
	}
	
	@Bean
	public ConfirmacionCompraTasklet confirmacionCompraTasklet() {
		return new ConfirmacionCompraTasklet();
	}
	
	@Bean
	public PagoTasklet pagoTasklet() {
		return new PagoTasklet();
	}
	
	@Bean
	public ErrorTasklet errorTasklet() {
		return new ErrorTasklet();
	}
	
	@Bean
	public Step stepLogin() {
		return stepBuilderFactory.get("stepLogin")
				.tasklet(loginTasklet())
				.build();
	}
	
	@Bean
	public Step stepConfirmacionCompra() {
		return stepBuilderFactory.get("stepConfirmacion")
				.tasklet(confirmacionCompraTasklet())
				.build();
	}
	
	@Bean
	public Step stepPago() {
		return stepBuilderFactory.get("stepPago")
				.tasklet(pagoTasklet())
				.build();
	}
	
	@Bean
	public Step errorStep() {
		return stepBuilderFactory.get("stepError")
				.tasklet(errorTasklet())
				.build();
	}
	
	/*
	@Bean
	public Job jobSecuencial() {
		return jobBuilderFactory.get("jobSecuencial")
				.start(stepLogin())
				.next(stepConfirmacionCompra())
				.next(stepPago())
				.build();
	}
	*/
	
	/*
	@Bean
	public Job jobCondicional() {
		return jobBuilderFactory.get("jobCondicional")
				.start(stepLogin())
					.on("FAILED").end()
					.on("*").to(stepConfirmacionCompra())
				.from(stepConfirmacionCompra())
					.on("FAILED").end()
					.on("*").to(stepPago())
				.from(stepPago())
					.on("FAILED").end()
				.end()
				.build();
				
	}
	*/
	
	// Incluimos stepError
	@Bean
	public Job jobCondicional() {
		return jobBuilderFactory.get("jobCondicional")
				.start(stepLogin())
					.on("FAILED").to(errorStep())
				.from(stepLogin())
					.on("COMPLETED").to(stepConfirmacionCompra())
				//	.on("*").to(stepConfirmacionCompra())   Tambien Funciona
				.from(stepConfirmacionCompra())
					.on("FAILED").to(errorStep())
				.from(stepConfirmacionCompra())
					.on("COMPLETED").to(stepPago())
				.from(errorStep())
					.on("*").end()
				.from(stepPago())
					.on("FAILED").to(errorStep())
				.end()
				.build();
				
	}
}







