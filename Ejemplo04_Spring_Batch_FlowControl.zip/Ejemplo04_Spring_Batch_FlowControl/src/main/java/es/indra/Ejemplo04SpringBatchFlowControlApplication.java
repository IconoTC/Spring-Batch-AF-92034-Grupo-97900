package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo04SpringBatchFlowControlApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo04SpringBatchFlowControlApplication.class, args);
	}

}
