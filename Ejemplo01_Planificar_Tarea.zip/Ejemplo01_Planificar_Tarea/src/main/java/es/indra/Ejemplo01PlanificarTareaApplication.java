package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo01PlanificarTareaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo01PlanificarTareaApplication.class, args);
	}

}
