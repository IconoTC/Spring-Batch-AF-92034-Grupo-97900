package es.indra.business;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class TareaProgramada {
	
	// Queremos que este metodo se ejecute cada 3 segundos 
	@Scheduled(fixedRate = 3000)
	public void mostrarMensaje() {
		System.out.println("Bienvenidos al curso de Spring Batch");
	}

}
