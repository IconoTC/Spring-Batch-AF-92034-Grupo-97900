DROP TABLE productos IF EXISTS;

CREATE TABLE productos (
	id integer NOT NULL PRIMARY KEY,
	descripcion VARCHAR(20),
	precio double
);