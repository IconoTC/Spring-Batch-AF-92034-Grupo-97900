package es.indra;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo03SpringBatchTaskletApplication implements CommandLineRunner{
	
	@Autowired
	private JobLauncher jobLauncher;
	
	@Autowired
	private Job job;

	// En los proyectos con Spring Boot el metodo main esta dedicado
	// solo a levantar el contexto de Spring
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo03SpringBatchTaskletApplication.class, args);
	}

	// Este metodo se ejecuta de forma automatica despues del metodo main
	@Override
	public void run(String... args) throws Exception {
		// Crear los parametros del Job
		JobParameters jobParameters = new JobParametersBuilder()
				.addString("prueba", "Esto es un parametro del job")
				.addLong("time", System.currentTimeMillis())
				.toJobParameters();
		
		// Se los asignamos al job en el momento de la ejecucion		
		// Lanzamos el job con JobLauncher
		JobExecution jobExecution = jobLauncher.run(job, jobParameters);
		
		System.out.println(jobExecution); 
		System.out.println("Exit Status: " + jobExecution.getExitStatus());
		System.out.println("Estado: " + jobExecution.getStatus());
	}

}
