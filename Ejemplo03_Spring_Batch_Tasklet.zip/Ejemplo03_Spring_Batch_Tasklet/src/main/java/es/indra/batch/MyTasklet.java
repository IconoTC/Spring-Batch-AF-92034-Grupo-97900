package es.indra.batch;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Service;

// Un tasklet se utiliza cuando el proceso del step es tan sencillo
// que no necesitamos el ItemReader, ItemWriter, ItemProcesor
@Service
public class MyTasklet implements Tasklet{

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		// Recuperar los parametros del Job
		System.out.println(chunkContext.getStepContext().getJobParameters().get("prueba"));
		long time = (long) chunkContext.getStepContext().getJobParameters().get("time");
		System.out.println("Time: " + time);
		
		System.out.println("Ejecutando el tasklet");
		return RepeatStatus.FINISHED;
	}

}
