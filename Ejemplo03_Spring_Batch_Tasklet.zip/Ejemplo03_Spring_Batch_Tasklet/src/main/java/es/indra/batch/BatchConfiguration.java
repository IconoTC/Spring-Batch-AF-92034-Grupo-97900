package es.indra.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private MyTasklet myTasklet;
	
	
	// Crear el job
	@Bean
	public Job job() {
		return jobBuilderFactory.get("taskletJob")
				.start(step1())
				.build();
	}
	
	// Crear el step
	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1")
				.tasklet(myTasklet)
				.build();
	}

}
