package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo10SpringBatchStepParalelosApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo10SpringBatchStepParalelosApplication.class, args);
	}

}
