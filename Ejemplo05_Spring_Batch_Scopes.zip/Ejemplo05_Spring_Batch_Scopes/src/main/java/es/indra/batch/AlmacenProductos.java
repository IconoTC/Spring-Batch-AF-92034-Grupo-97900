package es.indra.batch;

import java.util.ArrayList;
import java.util.List;

import es.indra.models.Producto;

public class AlmacenProductos {
	
	public static List<Producto> productos = new ArrayList<>();

}
