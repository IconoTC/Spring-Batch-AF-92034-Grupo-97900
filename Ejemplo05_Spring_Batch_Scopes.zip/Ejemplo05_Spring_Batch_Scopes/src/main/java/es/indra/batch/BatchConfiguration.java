package es.indra.batch;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import es.indra.models.Producto;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private DataSource dataSource;
	
	// Creo un bean del JobListener
	@Bean
	// En Spring todos los beans son scope=Singleton
	@JobScope // Le indico que genere una nueva instancia para cada job
	// Se usa para beans cuyo ciclo de vida e instancia debe ser unica para cada job
	// Util, por ejemplo, para listeners u objetos auxiliares del job
	public JobListener jobListener() {
		return new JobListener();
	}
	
	// Crear un job
	@Bean
	public Job crearJob() {
		return jobBuilderFactory.get("productosJob")
				.listener(jobListener())
				.flow(step1())
				.end()
				.build();
	}
	
	// Crear un step
	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1")
				.<Producto,Producto>chunk(2)  // nº de registros que leemos en cada bloque
				.reader(reader())
				.processor(processor())
				.writer(writer())
				.build();
	}
	
	// Crear un ItemReader
	@Bean
	@StepScope  // Crear una instancia distinta para cada step
	// Se recomienda en readers, processors, writers que dependen de parametros o contexto del step
	public FlatFileItemReader<Producto> reader(){
		return new FlatFileItemReaderBuilder<Producto>()
				.name("productoItemReader")
				.resource(new ClassPathResource("data.csv"))
				.delimited()
				.names("id", "descripcion", "precio")
				.fieldSetMapper(new BeanWrapperFieldSetMapper<Producto>() {
					{
						setTargetType(Producto.class);
					}
				}).build();
	}
	
	// Crear un ItemProcessor
	@Bean
	public ProcesadorProductos processor() {
		return new ProcesadorProductos();
	}
	
	// Crear un ItemWriter
	@Bean
	public JdbcBatchItemWriter<Producto> writer(){
		return new JdbcBatchItemWriterBuilder<Producto>()
				.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
				// Las propiedades del objeto producto son los parametros para insertar con la query 
				.sql("INSERT INTO productos (id, descripcion, precio) VALUES (:id, :descripcion, :precio)")
				.dataSource(dataSource)
				.build();
	}

}








